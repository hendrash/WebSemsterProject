package com.StudyGuide.StudyGuide;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudyGuideApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudyGuideApplication.class, args);
	}

}
